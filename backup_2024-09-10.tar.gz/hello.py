
Name = input("enter your swwt name : ")

print ("hello",Name)