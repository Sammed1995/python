day_of_week = input("enter day of the week : ").lower() #convert lowercase

print("Today day is : ",day_of_week)

if day_of_week == "saturday" or day_of_week == "sunday":

    print(" I Learn New Things")

else:
    print (" i do routines things")