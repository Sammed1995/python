num1 = int(input("Enter a  first number : ")) #string casting str > int
num2 = int(input("Enter a second num : "))

print(type(num1))
print(type(num2))

sum_of_two_num = num1 + num2

print("Sum of two num = ",sum_of_two_num)


dif_of_two_num = num1 - num2

print("Dif of two num = ",dif_of_two_num)


prod_of_two_num = num1 * num2

print("Prod of two num = ",prod_of_two_num)


div_of_two_num = num1 / num2

print("Div of two num = ",div_of_two_num)